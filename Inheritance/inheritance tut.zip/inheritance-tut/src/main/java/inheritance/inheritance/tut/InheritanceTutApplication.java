package inheritance.inheritance.tut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InheritanceTutApplication {

	public static void main(String[] args) {
		SpringApplication.run(InheritanceTutApplication.class, args);
	}

}
