package inheritance.inheritance.tut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InheritanceTutApplicationTests {

	@Test
	void contextLoads() {
	}

}
