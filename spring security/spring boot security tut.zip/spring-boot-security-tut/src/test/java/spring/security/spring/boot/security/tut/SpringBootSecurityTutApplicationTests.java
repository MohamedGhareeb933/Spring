package spring.security.spring.boot.security.tut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityTutApplicationTests {

	@Test
	void contextLoads() {
	}

}
